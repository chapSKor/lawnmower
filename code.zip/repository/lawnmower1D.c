/* compile with: gcc -o lawnmower1D -I/opt/local/include -L/opt/local/lib -O3 -lm -lgsl -lgslcblas lawnmower1D.c */
/* NOTE: to generate (Gaussian distributed) random numbers, this program uses the GSL library (https://www.gnu.org/software/gsl/) */ 

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/times.h>
#include <unistd.h>
#include <time.h>

/* include required definitions (header files) */
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>

/* signature of output file names */
const char out[]     = "lm1_";


/****** CONTROL EXPERIMENT: normal diffusion ******/
/*** 28 trajectories in vertical channels with number of observed frames (i.e. trajectory length in sec): ***/
/*** 3431, 989, 1586, 689, 813, 2180, 4492, 1259, 5323, 2841, 1430, 1768, 2151, 1324, 980, 1239, 1258, 1607, 2319, 2065, 1863, 1790, 1588, 1036, 851, 708 ***/
/*** averages: mean displacement = 0.00314292, sigma = 0.347541, kurtosis = 3.00962 ***/


/*** begin: best fit of free diffusion control experiment ***/
/*** (fitting first and second moment of displacment distribution) ***/
// const unsigned long nFrames = 708;
// const unsigned long nTrajectories = 20;
//
// const double bias = 0.0;  /* free diffusion */
// const double pDrift = 0.000032; /* net drift for vertical channels */
// const double pDrift = 0.0;
// const unsigned int nStepsPerFrame = 20000;
// const double length = 0.00235;
/*** end: best fit of free diffusion control experiment ***/


/****** EXPERIMENT 1 ******/
/*** 18 trajectories in horizontal channels with number of observed frames (i.e. trajectory length in sec): ***/
/*** 1628, 1050, 671, 490, 834, 6788, 3455, 5801, 1873, 1665, 5662, 873, 4598, 870, 760, 740, 2479, 1036 ***/
/*** averages: mean displacement = 0.0106177, sigma = 0.337541, kurtosis = 3.33509 ***/
/*** 21 trajectories in vertical channels with number of observed frames (i.e. trajectory length in sec): ***/
/*** 3910, 1515, 6788, 5181, 3450, 2593, 3194, 6788, 1555, 3389, 2934, 4504, 6422, 1005, 4970, 1690, 4645, 2246, 2068, 1420, 1054 ***/
/*** averages: mean displacement = 0.00743791, sigma = 0.331242, kurtosis = 3.24949 ***/


/*** begin: best fit of free diffusion to experiment 1 ***/
/*** (fitting first and second moment of displacment distribution) ***/
// const unsigned long nFrames = 1036;
// const unsigned long nTrajectories = 20;
//
// const double bias = 0.0;  /* free diffusion */
// const double pDrift = 0.00011; /* net drift for horizontal channels in experiment1 */
//const double pDrift = 0.000077; /* net drift for vertical channels in experiment1 */
//const double pDrift = 0.00009; /* net drift for all channels in experiment1 */
// const double pDrift = 0.0;
// const unsigned int nStepsPerFrame = 20000;
// const double length = 0.00235;
/*** end: best fit to free diffusion experiment ***/

/*** begin: best fit to experiment 1 ***/
// const unsigned long nFrames = 2900;
// const unsigned long nTrajectories = 39;

const unsigned long nFrames = 2900;
const unsigned long nTrajectories = 500;

const double bias = 0.12;
const double pDrift = 0.000057;
const unsigned int nStepsPerFrame = 20000;
const double length = 0.0023;

/* to reproduce kurtosis value of exp1 */
// const unsigned long nFrames = 700;
// const unsigned long nTrajectories = 160;
/*** end: best fit to experiment 1 ***/


// const double bias = 0.15;
// const double pDrift = 0.0; /* systematic drift -> p,q = 1/2+-pDrift */

const unsigned int nTrajObs = 1000;
const unsigned int histBinning = 20;  /* for final positions */

/*** basic quantities for random walk after one frame       ***/
/*** (i.e. valid only for bias = 0.0, free diffusion)       ***/
/*** net drift per frame = nStepsPerFrame*length * 2*pDrift ***/
/*** variance per frame  = nStepsPerFrame*length*length     ***/
/***                         * (1 - 4*pDrift*pDrift)        ***/


/* transformation between integer position (x,y) and storage position in array */
#define ARRAY_POS(X)  ((unsigned long)((X)+nFrames*nStepsPerFrame))

/* pointer to random number generator */
gsl_rng *rng;

/*** two-dimensional lawnmower ***/
int *sites;   /* sites visited */

/* returns probability for stepping to the right */
const double
px( const long int x )
{
  double p = 0.5+pDrift;

  /* 1) normal Brownian motion */
  //return p;

  /* 2) higher probability to move towards previously unvisited sites */
  if     ( x ==  (long int) nFrames*nStepsPerFrame ) p = 0.0;
  else if( x == -(long int) nFrames*nStepsPerFrame ) p = 1.0;
  else if( sites[ARRAY_POS(x+1)] == 0 && sites[ARRAY_POS(x-1)] > 0 ) p += bias;
  else if( sites[ARRAY_POS(x-1)] == 0 && sites[ARRAY_POS(x+1)] > 0 ) p -= bias;
  return p;
}


int
main( void )
{
    /* number of bins for final-position histograms */
    const unsigned long nxBins2 = (unsigned long) ceil( (double) nFrames*nStepsPerFrame / histBinning );
    /* for hostname */
    char hostname[256];
    /* for initial and final CPU time */
    struct tms tstart, tend;
    /* initialization of random number generator with some seed */
    long int seed = (long int) time( NULL );
    FILE *fp;

    if( 0.5+pDrift+bias > 1.0 ) {
      printf( "warning: total probability 0.5+pDrift+bias for preferred jump larger than 1 ... exit\n" );
      exit( 1 );
    }

    /* observations */
    long int *xObs, *x2Obs;
    long int *histDeltax, *histFinalx;
    if( (xObs = (long int *) calloc( (unsigned long) nFrames, sizeof( long int ) )) == NULL ) {
      fprintf( stderr, "error: cannot allocate memory for xObs... exit\n" );
      exit( 1 );
    }
    if( (x2Obs = (long int *) calloc( (unsigned long) nFrames, sizeof( long int ) )) == NULL ) {
      fprintf( stderr, "error: cannot allocate memory for x2Obs... exit\n" );
      exit( 1 );
    }
    if( (histDeltax = (long int *) calloc( (unsigned long) 2*nStepsPerFrame+1, sizeof( long int ) )) == NULL ) {
      fprintf( stderr, "error: cannot allocate memory for histDeltax... exit\n" );
      exit( 1 );
    }
    /* +1 only needed for the alternative binning with centered 0 bin */
    if( (histFinalx = (long int *) calloc( (unsigned long) 2*nxBins2+1, sizeof( long int ) )) == NULL ) {
      fprintf( stderr, "error: cannot allocate memory for histFinalx... exit\n" );
      exit( 1 );
    }


    /* get hostname */
    gethostname ( hostname, 256 );
    hostname[(int) strcspn(hostname, ".")] = '\0';

    /* one of several ways to set the seed of the generator */
    gsl_rng_default_seed = seed;
    /* allocate random number generator with the default generator type */
    rng = gsl_rng_alloc( gsl_rng_default );       /* gsl_rng_default = gsl_rng_mt19937 */

    /* simulations start */
    times( &tstart );
    /* the different runs */
    for( unsigned long nt = 0; nt < nTrajectories; nt++ )
    {
      char file[64];
      /* file for saving data */
      if( nt < nTrajObs ) {
        sprintf( file, "%s%lu_traj.%lu.dat", out, nFrames, nt+1 );
        fp = fopen( file, "w" );
        fprintf( fp, "### 1D trajectory of lawnmower\n" );
        fprintf( fp, "### nStepsPerFrame = %u ,  length (per frame) = %g\n", nStepsPerFrame, length );
        fprintf( fp, "### pDrift = %g    (unbiased diffusion if 0)\n", pDrift );
        fprintf( fp, "### bias = %g    (gives free diffusion if 0)\n", bias );
        fprintf( fp, "###\n" );
        fprintf( fp, "# frame\t\tx\t\tdeltax\n");
      }

      /* (x,y) is current position, always starting at (0,0), sites are sites visited */
      if( (sites = (int *) calloc( (unsigned long)(2*nFrames*nStepsPerFrame+1), sizeof( int ) )) == NULL ) {
        //fprintf( stderr, "error: cannot allocate memory for sites in run %lu... exit\n", nt );
        fprintf( stderr, "error: cannot allocate memory for sites for run %lu... exit\n", nt );
        exit( 1 );
      }
      long int x = 0;
      sites[ARRAY_POS(x)]++;

      /* current run */
      for( unsigned long n = 0; n < nFrames; n++ )
      {
        const long int xPrev = x;  /* store current position */
        /* do nStepsPerFrame steps until next observation */
        for( unsigned int ns = 0; ns < nStepsPerFrame; ns++ )
        {
          /*** begin: single time-step ***/
          /*** (steps in x and y direction are independent) ***/
          /* step in x direction */
          if( gsl_rng_uniform( rng ) < px( x ) ) x++; /* move to right */
          else x--;        /* move to left */
          sites[ARRAY_POS(x)]++;   /* monitor visit of current site */
          /*** end: single time-step ***/
        }

        /* observation of positions */
        xObs[n] += x; x2Obs[n] += x*x;
        /* histogram of displacements between frames */
        histDeltax[x-xPrev+nStepsPerFrame]++;
        /* if( nt < nTrajObs ) fprintf( fp, "%lu\t\t%ld\t\t%ld\n", n+1, x, x-xPrev ); */
        if( nt < nTrajObs ) fprintf( fp, "%lu\t\t%g\t\t%g\n", n+1, (double) x*length, (double) (x-xPrev)*length );
      }
      if( nt < nTrajObs ) fclose( fp );
      free( sites ); /* free memory for the current run */

      /* histogram of final positions */
      /* alternative binning with 0 as the center */
      // const long int xbin = (int) (( x + (x<0 ? -((long int) histBinning/2) : ((long int) histBinning/2) ) / histBinning);
      // const long int xBinned = xbin*histbinning;
      /* binning with 0 separating two bins */
      long int xBin = (long int) ( x - (x<=0 ? ((long int) histBinning) : 1) ) / ((long int) histBinning);
      if( xBin < -(long int) nxBins2 ) xBin = -(long int) nxBins2;  /* can happen at the negative boundary */
      // const int xBinned = xbin*histBinning+histBinning/2;
      histFinalx[xBin+nxBins2]++;
    }
    /* simulations end */
    times( &tend );

    /* MSD */
    char file[64];
    sprintf( file, "%s%lu_MSD.dat", out, nFrames );
    fp = fopen( file, "w" );
    fprintf( fp, "### ensemble average of MSD for lawnmower\n" );
    fprintf( fp, "### number of trajectories: %lu ,   number of frames per trajectory: %lu\n", nTrajectories, nFrames );
    fprintf( fp, "### nStepsPerFrame = %u ,  length (per frame) = %g\n", nStepsPerFrame, length );
    fprintf( fp, "### pDrift = %g    (unbiased diffusion if 0)\n", pDrift );
    fprintf( fp, "### bias = %g    (gives free diffusion if 0)\n", bias );
    fprintf( fp, "###\n" );
    fprintf( fp, "# frame\t\txAv\t\tMSD\n");
    for( int n = 0; n < nFrames; n++ )
    {
      const double xAv  = xObs[n] /((double) nTrajectories);
      const double x2Av = x2Obs[n]/((double) nTrajectories);
      /* fprintf( fp, "%d\t%g\t%g\n", n, xAv, x2Av-xAv*xAv ); */
      fprintf( fp, "%d\t%g\t%g\n", n, xAv*length, (x2Av-xAv*xAv)*length*length );
    }
    fclose( fp );

    /* histograms... */
    /* ... for final positions */
    long int nData = 0; /* count data points */
    for( long int xBin = -((long int)nxBins2); xBin <= ((long int)nxBins2); xBin++ )
      nData += histFinalx[xBin+nxBins2];
    sprintf( file, "%s%lu_HistFinalx.dat", out, nFrames );
    fp = fopen( file, "w" );
    fprintf( fp, "### histogram of final positions for lawnmower\n" );
    fprintf( fp, "### number of trajectories: %lu ,   number of frames per trajectory: %lu\n", nTrajectories, nFrames );
    fprintf( fp, "### nStepsPerFrame = %u ,  length (per frame) = %g\n", nStepsPerFrame, length );
    fprintf( fp, "### pDrift = %g    (unbiased diffusion if 0)\n", pDrift );
    fprintf( fp, "### bias = %g    (gives free diffusion if 0)\n", bias );
    fprintf( fp, "###\n" );
    fprintf( fp, "# position\t\tprob\n" );
    for( long int xBin = -((long int)nxBins2); xBin <= ((long int)nxBins2); xBin++ ) {
      if( histFinalx[xBin+nxBins2] > 0 )
        /*fprintf( fp, "%ld\t%g\n",
          xBin*histBinning+histBinning/2, (double) histFinalx[xBin+nxBins2]/histBinning/nData );*/
        fprintf( fp, "%g\t%g\n",
          (double) (xBin*histBinning+histBinning/2)*length,
          (double) histFinalx[xBin+nxBins2]/(histBinning*length)/nData );
    }
    fclose( fp );
    /* ... for displacements */
    nData = 0; /* count data points */
    double av = 0.0, sqrAv = 0.0; /* and calculate averages */
    for( long int x = -((long int)nStepsPerFrame); x < ((long int)nStepsPerFrame)+1; x++ ) {
      av    += ((double) x) * ((double) histDeltax[x+nStepsPerFrame]);
      sqrAv += ((double) x)*((double) x) * ((double) histDeltax[x+nStepsPerFrame]);
      nData += histDeltax[x+nStepsPerFrame];
    }
    av    /= (double) nData; av    *= length;
    sqrAv /= (double) nData; sqrAv *= length*length;
    const double sigma = sqrt(sqrAv-av*av);
    /* calculate sample kurtosis */
    double kurt = 0.0;
    for( long int x = -((long int)nStepsPerFrame); x < ((long int)nStepsPerFrame)+1; x++ ) {
      const double z = ((double)x*length-av)/sigma;
      kurt += z*z*z*z * ((double) histDeltax[x+nStepsPerFrame]);
    }
    kurt /= nData;
    sprintf( file, "%s%lu_HistDeltax.dat", out, nFrames );
    fp = fopen( file, "w" );
    fprintf( fp, "### histogram of displacements for lawnmower\n" );
    fprintf( fp, "### number of trajectories: %lu ,   number of frames per trajectory: %lu\n", nTrajectories, nFrames );
    fprintf( fp, "### nStepsPerFrame = %u ,  length (per frame) = %g\n", nStepsPerFrame, length );
    fprintf( fp, "### pDrift = %g    (unbiased diffusion if 0)\n", pDrift );
    fprintf( fp, "### bias = %g    (gives free diffusion if 0)\n", bias );
    fprintf( fp, "###\n" );
    fprintf( fp, "### total number of displacements: %ld\n", nData );
    fprintf( fp, "### averages: mean displacement = %g\n", av );
    fprintf( fp, "###           sigma             = %g\n", sigma );
    fprintf( fp, "###           kurtosis          = %g\n", kurt );
    fprintf( fp, "###             (note: kurtosis = 3.0 for a Gaussian distribution)\n" );
    fprintf( fp, "###\n" );
    fprintf( fp, "# displacement\tprob\n" );
    for( long int x = -((long int)nStepsPerFrame); x < ((long int)nStepsPerFrame)+1; x++ )
      if( histDeltax[x+nStepsPerFrame] > 0 )
        /*fprintf( fp, "%ld\t%g\n", x, (double) histDeltax[x+nStepsPerFrame]/histBinning/nData );*/
        fprintf( fp, "%g\t%g\n",
          (double) x*length,
          (double) histDeltax[x+nStepsPerFrame]/(2*length)/((double)nData) ); /* bin size for delta is always 2 */
    fclose( fp );

    /* logging of simulation time */
    printf( "# runs = %lu    (CPU time: %gs on %s)\n",
            nTrajectories, (double) (tend.tms_utime - tstart.tms_utime)/sysconf( _SC_CLK_TCK ), hostname );

    free( xObs ); free( x2Obs );
    free( histFinalx );
    free( histDeltax );

    return 0;
}
